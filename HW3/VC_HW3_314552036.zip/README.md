run the script:
    python motion_esimation.py