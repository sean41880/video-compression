run:
python run_length_encoding.py