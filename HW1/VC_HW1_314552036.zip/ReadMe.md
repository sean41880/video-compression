To run the code:
    python HW1.py